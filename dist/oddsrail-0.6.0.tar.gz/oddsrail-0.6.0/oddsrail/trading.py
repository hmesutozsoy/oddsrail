"""Order routing with on-chain builder-code attribution (CLOB V2).

How attribution works (verified against docs.polymarket.com, Aug 2026):
the operator's bytes32 builder code — from polymarket.com/settings?tab=builder —
is placed in the `builder` field of the V2 order struct BEFORE signing, so
attribution is on-chain: every OrderFilled event on CTF Exchange V2 carries it,
and builder fees (taker <= 100 bps, maker <= 50 bps, additive to platform fees)
settle to the builder-profile wallet.

Attribution defaults (how this project sustains itself):
oddsrail ships with a project builder code set at 0 bps, so routed orders are
attributed by default. At 0 bps this costs the operator NOTHING — no fee is
added to any trade — and the project earns only a share of Polymarket's
weekly builder reward pool, which Polymarket pays out of its own program.
Set ODDSRAIL_BUILDER_CODE to your own code to claim that share instead; the
project code is a default, never a lock-in. server_info reports which is
in use.

Safety model:
- ODDSRAIL_DRY_RUN=1 (default): place_order returns the exact order it WOULD
  post, never touches the exchange. Set ODDSRAIL_DRY_RUN=0 to trade.
- Trading requires POLYMARKET_PRIVATE_KEY (+ POLYMARKET_WALLET_ADDRESS for
  proxy/deposit wallets). Keys stay on this machine — oddsrail is self-hosted
  and non-custodial by design.
"""

import os

_secure = None


def dry_run() -> bool:
    return os.environ.get("ODDSRAIL_DRY_RUN", "1") not in ("0", "false", "no")


# The project's own builder code ("oddsrail" builder profile), applied when the
# operator has not set one. Registered at 0 bps maker / 0 bps taker, so it
# attributes routed flow without adding a fee to anyone's trade.
DEFAULT_BUILDER_CODE = "0xa576c5ce9fabba322d8fa3a8d16738221d1b6b2b0c57b544f757fa9e45a09a90"


def builder_code() -> str | None:
    """Operator's code if set, else the project default (may be empty)."""
    return os.environ.get("ODDSRAIL_BUILDER_CODE") or DEFAULT_BUILDER_CODE or None


def builder_code_source() -> str:
    if os.environ.get("ODDSRAIL_BUILDER_CODE"):
        return "operator (ODDSRAIL_BUILDER_CODE)"
    if DEFAULT_BUILDER_CODE:
        return "oddsrail project default (0 bps — no fee added; override with ODDSRAIL_BUILDER_CODE)"
    return "none configured"


async def _client():
    global _secure
    if _secure is None:
        from polymarket import AsyncSecureClient
        key = os.environ.get("POLYMARKET_PRIVATE_KEY")
        if not key:
            raise RuntimeError(
                "POLYMARKET_PRIVATE_KEY not set — trading tools are disabled. "
                "Read-only tools work without it.")
        _secure = await AsyncSecureClient.create(
            private_key=key,
            wallet=os.environ.get("POLYMARKET_WALLET_ADDRESS"),
        )
    return _secure


def _intent(token_id, side, price, size, post_only):
    code = builder_code()
    return {
        "exchange": "polymarket",
        "token_id": token_id,
        "side": side,
        "price": price,
        "size": size,
        "size_unit": "shares (notional = price * size, in USDC)",
        "post_only": post_only,
        "builder_code": code,
        "attribution": ("on-chain: builder code signed into the order "
                        f"[{builder_code_source()}]"
                        if code else
                        "NONE — no builder code configured"),
    }


async def place_order(token_id: str, side: str, price: float, size: float,
                      post_only: bool = False):
    side = side.upper()
    if side not in ("BUY", "SELL"):
        raise ValueError("side must be BUY or SELL")
    if not (0 < price < 1):
        raise ValueError("price is an implied probability in (0, 1)")
    if size <= 0:
        raise ValueError("size must be positive (number of shares)")

    intent = _intent(token_id, side, price, size, post_only)
    if dry_run():
        return {"dry_run": True, "would_post": intent,
                "note": "set ODDSRAIL_DRY_RUN=0 to post real orders"}

    client = await _client()
    from .polymarket import dump
    try:
        resp = await client.place_limit_order(
            token_id=token_id, price=str(price), size=str(size), side=side,
            post_only=post_only, builder_code=builder_code())
    except Exception as e:
        return {"dry_run": False, "accepted": False,
                "error_type": type(e).__name__, "error": str(e),
                "submitted": intent,
                "note": "the exchange rejected the request; nothing was signed onto the book"}
    d = dump(resp)
    # The SDK models rejection as a RETURN VALUE (ok=False), not an exception.
    # Reporting that under a key called "posted" — next to an attribution
    # string claiming the order was signed on-chain — reads to an agent as
    # success. Branch on it.
    ok = bool(d.get("ok", True)) if isinstance(d, dict) else True
    if not ok:
        return {"dry_run": False, "accepted": False,
                "rejected_code": d.get("code"),
                "rejected_reason": d.get("message"),
                "submitted": intent,
                "note": "rejected by the exchange — no order rests, nothing was attributed"}
    return {"dry_run": False, "accepted": True, "order": d, "submitted": intent}


async def cancel_order(order_id: str):
    if dry_run():
        return {"dry_run": True, "would_cancel": order_id}
    client = await _client()
    from .polymarket import dump
    try:
        # SDK signature is cancel_order(*, order_id=...) — keyword-only.
        return {"ok": True, "order_id": order_id,
                "response": dump(await client.cancel_order(order_id=order_id))}
    except Exception as e:
        # An agent pulling a stale quote off a moving market needs to know
        # whether it is still exposed, not just that Python raised.
        return {"ok": False, "order_id": order_id,
                "error_type": type(e).__name__, "error": str(e),
                "still_resting": "unknown — call open_orders to confirm"}


async def open_orders():
    if not os.environ.get("POLYMARKET_PRIVATE_KEY"):
        return {"note": "no trading key configured; nothing to list"}
    client = await _client()
    from .polymarket import dump
    page = await client.list_open_orders().first_page()
    return dump(list(page.items))


async def order_status(order_id: str):
    """Lifecycle answer for one order: resting / filled / gone.

    Without this an agent that placed an order was blind — open_orders shows
    presence but not fill progress, and a vanished id is ambiguous between
    "filled" and "cancelled". get_order reports size_matched directly.
    """
    if not os.environ.get("POLYMARKET_PRIVATE_KEY"):
        return {"note": "no trading key configured"}
    client = await _client()
    from .polymarket import dump
    try:
        d = dump(await client.get_order(order_id=order_id))
        matched = float(d.get("size_matched") or 0)
        size = float(d.get("original_size") or d.get("size") or 0)
        state = ("filled" if size and matched >= size else
                 "partially_filled" if matched > 0 else "resting")
        return {"found": True, "state": state, "size_matched": matched,
                "original_size": size, "order": d}
    except Exception as e:
        return {"found": False,
                "note": ("order not found — it either fully filled and left the "
                         "book, was cancelled, or never existed. my_fills() "
                         "shows recent executions."),
                "error_type": type(e).__name__, "error": str(e)[:200]}


async def cancel_all_orders():
    """Kill switch: pull every resting order on the operator's account."""
    if dry_run():
        return {"dry_run": True,
                "would_cancel": "ALL resting orders on the operator account"}
    client = await _client()
    from .polymarket import dump
    try:
        return {"ok": True, "response": dump(await client.cancel_all())}
    except Exception as e:
        return {"ok": False, "error_type": type(e).__name__, "error": str(e),
                "still_resting": "unknown — call open_orders to confirm"}


def operator_wallet() -> str | None:
    return (os.environ.get("POLYMARKET_WALLET_ADDRESS")
            or os.environ.get("POLYMARKET_FUNDER") or None)


async def my_fills(limit: int = 25):
    """Recent executions for the operator wallet, from the Data API activity
    feed. Deliberately NOT list_account_trades(): that SDK call returns the
    market's PUBLIC tape (other people's trades) — a verified footgun."""
    wallet = operator_wallet()
    if not wallet:
        return {"note": "set POLYMARKET_WALLET_ADDRESS to see fills"}
    import httpx
    async with httpx.AsyncClient(timeout=20.0) as h:
        r = await h.get("https://data-api.polymarket.com/activity",
                        params={"user": wallet, "limit": limit, "type": "TRADE"})
        r.raise_for_status()
        acts = r.json()
    return {"wallet": wallet, "fills": [
        {"time": a.get("timestamp"), "side": a.get("side"),
         "size": a.get("size"), "price": a.get("price"),
         "market": str(a.get("title"))[:80], "tx": a.get("transactionHash")}
        for a in (acts if isinstance(acts, list) else [])]}
